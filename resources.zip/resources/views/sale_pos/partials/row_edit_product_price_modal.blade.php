<div class="modal-dialog" role="document">
	<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title" id="myModalLabel">{{$product->product_name}} - {{$product->sub_sku}}</h4>
		</div>
		<div class="modal-body">
			<div class="row">
				<div class="form-group col-xs-6 hide">
					<label>@lang('sale.unit_price')</label>
					<input type="text" name="products[{{$row_count}}][unit_price]" class="form-control pos_unit_price_temp_ input_number mousetrap" value="{{@num_format($product->default_sell_price)}}">
					<input type="hidden" class="form-control pos_unit_price input_number mousetrap" value="{{@num_format($product->default_sell_price)}}">
				</div>

				<div class="form-group col-xs-6 hide">
					{!! Form::label('currency_country_', __('currencies.currency') . ':*') !!}
					{!! Form::select('currency_country_', $currencies, $default_currency_id, ['class' => 'form-control', 'id' => 'currency_rate_', 'required']); !!}

				</div>
				<div class="clearfix"></div>
				@php
					$discount_type = !empty($product->line_discount_type) ? $product->line_discount_type : 'fixed';
					$discount_amount = !empty($product->line_discount_amount) ? $product->line_discount_amount : 0;
				@endphp
				<div class="form-group col-xs-12 col-sm-6 hide">
					<label>@lang('sale.discount_type')</label>
						{!! Form::select("products[$row_count][line_discount_type]", ['fixed' => __('lang_v1.fixed'), 'percentage' => __('lang_v1.percentage')], $discount_type , ['class' => 'form-control row_discount_type']); !!}
				</div>
				<div class="form-group col-xs-12 col-sm-6 hide">
					<label>@lang('sale.discount_amount')</label>
						{!! Form::text("products[$row_count][line_discount_amount]", @num_format($discount_amount), ['class' => 'form-control input_number row_discount_amount']); !!}
				</div>
				<div class="form-group col-xs-12 {{$hide_tax}}">
					<label>@lang('sale.tax')</label>
						<input type="hidden" name="products[{{$row_count}}][item_tax]" class="form-control item_tax" value="{{$item_tax}}">
		
					{!! Form::select("products[$row_count][tax_id]", $tax_dropdown['tax_rates'], $tax_id, ['placeholder' => 'Select', 'class' => 'form-control tax_id'], $tax_dropdown['attributes']); !!}
				</div>
			</div>
		</div>
		<div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">@lang('messages.close')</button>
		</div>

	</div>
</div>