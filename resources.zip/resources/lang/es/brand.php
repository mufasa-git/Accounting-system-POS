<?php 
 return [ 
"brands" => "Marcas",
"manage_your_brands" => "Gestiona tus marcas",
"all_your_brands" => "Todas tus marcas", /* modified */
"note" => "Nota",
"brand_name" => "Nombre de la marca",
"short_description" => "Breve descripción",
"added_success" => "Marca añadida con éxito",
"updated_success" => "Marca actualizada con éxito",
"deleted_success" => "Marca eliminada con éxito",
"add_brand" => "Agregar marca",
"edit_brand" => "Editar marca",
];