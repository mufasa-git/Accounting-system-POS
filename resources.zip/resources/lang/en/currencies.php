<?php

return [
    'currency' => 'Currencies',
    'currencies' => 'Currency',
    'manage_your_currency' => 'Manage your business currencies',
    'all_your_currencies' => 'All your currencies',
    'country' => 'Country',
    'currency_name' => 'Currency',
    'code' => 'Code',
    'symbol' => 'Symbol',
    'rate' => 'Rate',
    'edit_currency' => 'Edit Currency',
];
