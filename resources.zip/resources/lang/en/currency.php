<?php

return [
    'updated_success' => 'Currency updated successfully',

];
