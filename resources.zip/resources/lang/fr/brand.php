<?php 
 return [ 
"brands" => "Marques",
"manage_your_brands" => "Gérez vos marques",
"all_your_brands" => "Toutes vos marques",
"note" => "Remarque",
"brand_name" => "Marque",
"short_description" => "Brève description",
"added_success" => "Marque ajoutée avec succès",
"updated_success" => "Marque mise à jour avec succès",
"deleted_success" => "Marque supprimée avec succès",
"add_brand" => "Ajouter une marque",
"edit_brand" => "Modifier la marque",
];